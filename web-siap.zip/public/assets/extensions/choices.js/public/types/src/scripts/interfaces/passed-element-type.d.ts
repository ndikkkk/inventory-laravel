export type PassedElementType = 'text' | 'select-one' | 'select-multiple';
//# sourceMappingURL=passed-element-type.d.ts.map