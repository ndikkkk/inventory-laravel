declare function _exports(on: any, config: any): void;
export = _exports;
//# sourceMappingURL=index.d.ts.map